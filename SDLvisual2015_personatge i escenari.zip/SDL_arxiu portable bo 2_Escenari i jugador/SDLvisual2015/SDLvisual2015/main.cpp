#include <iostream>
#include "include/SDL.h"
#include "include/SDL_image.h"
#pragma comment( lib, "SDL/lib/x86/SDL2.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2_image.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2main.lib")

#define MASK 255, 255, 255



SDL_Window* Window = 0;
SDL_Renderer* renderer = 0;

int main(int argc, char* args[]) {

	SDL_Rect rect, rect2,fondo;

	

	SDL_Texture* billy = NULL;

	SDL_Surface* screen = NULL;
	
	SDL_Texture* screen2 = NULL;

	int posx = 100, posy = 100, width = 640, height = 480;




	SDL_Init(SDL_INIT_EVERYTHING);


	Window = SDL_CreateWindow("GUN.SMOKE", posx, posy, width, height, SDL_WINDOW_SHOWN);  // crea una finestra amb un nom, posicio x, y, tamany i flags.
	
	renderer = SDL_CreateRenderer(Window, -1, SDL_RENDERER_PRESENTVSYNC);  //Genera la finestra i sincronitza les imatges dins del Window.

	screen = SDL_LoadBMP("stage.bmp"); //textura enmagatzema el bmp del escenari

	screen2 = SDL_CreateTextureFromSurface(renderer, screen);

	SDL_RenderCopy(renderer, screen2, NULL, &fondo);

	


	//Asignem a la variable de textura el BMP.
	billy = SDL_CreateTextureFromSurface(renderer, SDL_LoadBMP("player1.bmp"));
	
	//Asignem el tamany del rectangle que emmagatzemara la imatge de fondo.

	fondo.x = 0;
	fondo.y = 0;
	fondo.w = width;
	fondo.h = height;

	//Dimensions recuadre personatge controlable.
		rect.x = 50;
		rect.y = 50;
		rect.w = 50;
		rect.h = 50;

		//Balas/Laser.
		rect2.x == rect.x; //El simbol = asigna la posicio de rect.x , pero no es exacte, el cuadradet no seguia el jugador.
		rect2.y == rect.y; //El simbol = asigna la posicio de rect.y , pero no es exacte, el cuadradet no seguia el jugador.
		rect2.w = 10;
		rect2.h = 10;

		
		SDL_Event event;
		bool running = true;
		bool up = false;
		bool right = false;
		bool left = false;
		bool down = false;
		bool bullet = false;
		bool bullet2 = false;
		bool bullet3 = false;

		while (running) {
			
			if (SDL_PollEvent(&event)) {

				if(event.type == SDL_KEYDOWN){  
				
						switch (event.key.keysym.sym) {
							
						case SDLK_ESCAPE:
							running = false;
							break;

						case SDLK_UP:
							
							up = true;
							break;

						case SDLK_DOWN:
							
							down = true;
							break;

						case SDLK_LEFT:
							
							left = true;
							
							break;

						case SDLK_SPACE: //tir dret.                        //Detecta la tecla space.
							bullet3 = true; //detecta que activa el bolea.
							rect2.x = rect.x + 25;	//es situa a la mateixa posicio X que el rectangle movil.
							rect2.y = rect.y + 45;   //es situa a la mateixa posicio Y que el rectangle movil.
							break;

						case SDLK_LCTRL: //tir esquerra
							bullet2 = true;
							rect2.x = rect.x + 25;
							rect2.y = rect.y;
							break; 

						case SDLK_LALT: //Tir central
							bullet = true;
							rect2.x = rect.x + 25;
							rect2.y = rect.y + 25;
							break;

						case SDLK_RIGHT:
							
							right = true;
							break;

						default:
							break;
						}
					}
				if (event.type == SDL_KEYUP) {

					switch (event.key.keysym.sym) {
	
					case SDLK_UP:
						up = false;
						break;

					case SDLK_DOWN:
						down = false;
						break;

					case SDLK_LEFT:
						left = false;
						break;

					case SDLK_RIGHT:
						right = false;
						break;
					default:
						break;
					}
				}
			}	

			//Limits de la finestra.
			if (rect.y != 0 && up) rect.y -= 5;
			if (rect.y != 430 && down) rect.y += 5;
			if (rect.x != 0 && left) rect.x -= 5;
			if (rect.x != 590 && right) rect.x += 5;
			

			

				////Tir recte.    Left ALT
				if (bullet) {
					rect2.x += 10;
					
				}

				////Tir diagonal ascendent   Left control.
				if (bullet2) {
					rect2.x += 10;
					rect2.y -= 10;
					
				}

				////Tir diagonal descendent       SPACE 
				if (bullet3) {
					rect2.x += 10;
					rect2.y += 10;
					
				}



				//Imprimeix el escenari com a fons de pantalla
				SDL_RenderCopy(renderer, screen2, NULL, &fondo);
				SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
				



				//Imprimeix les balas.
				SDL_SetRenderDrawColor(renderer, 0, 0, 234, 255);
				SDL_RenderFillRect(renderer, &rect2);
				
	

				//Copia imatge bmp sobre del rectangle previament creat.
				SDL_RenderCopy(renderer, billy, NULL, &rect);  



				//Mostra el rectangle amb la imatge.
				SDL_RenderPresent(renderer); 
			
		}

		


	SDL_Quit();
	return EXIT_SUCCESS;
}



//cada SDL fillrect rquereix un SDL_RenderCopy 


